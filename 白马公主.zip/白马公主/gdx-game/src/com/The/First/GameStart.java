package com.The.First;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.ui.Window.WindowStyle;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import javax.microedition.khronos.opengles.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.audio.*;

public class GameStart implements Screen
{
	MyGdxGame game;
	
	public static final float WORLD_WIDTH = 2048;
    public static final float WORLD_HEIGHT = 1080;

    SpriteBatch batch;
    Stage stage;

	private Button start;
	private Texture upTexture;
	private Texture downTexture;

	private Button start1;
	private Texture upTexture1;
	private Texture downTexture1;
	
	private Button ButtonMusic;
	private Texture upMusicTexture;
	private Texture donwMusicTexture;
	
	private Button ButtonMusic1;
	private Texture upMusicTexture1;
	private Texture donwMusicTexture1;

	TextureRegion background;
	BitmapFont font;

	Image image;
	
	public GameStart(MyGdxGame game){
		this.game = game;
		stage = new Stage(new StretchViewport(WORLD_WIDTH, WORLD_HEIGHT));
		hello();
		
	}

	private void hello()
	{
		Gdx.input.setInputProcessor(stage);
		Texture texture = new Texture("BackgroundGame.jpg");
		image = new Image();
        image.setDrawable(new TextureRegionDrawable(new TextureRegion(texture)));
        image.setSize(image.getPrefWidth(), image.getPrefHeight());
        image.setPosition(0, 0);
		stage.addActor(image);

        upTexture = new Texture(Gdx.files.internal("button1.png"));
        downTexture = new Texture(Gdx.files.internal("button2.png"));
        Button.ButtonStyle style = new Button.ButtonStyle();
        style.up = new TextureRegionDrawable(new TextureRegion(upTexture));
        style.down = new TextureRegionDrawable(new TextureRegion(downTexture));
        start = new Button(style);
        start.setPosition(100, 200);
        start.addListener(new ClickListener() {
				@Override
				public void clicked(InputEvent event, float x, float y) {
					ButtonStart();
					game.music.play();
				}
			});
		stage.addActor(start);
		
		upMusicTexture = new Texture(Gdx.files.internal("Music1.png"));
		donwMusicTexture = new  Texture(Gdx.files.internal("Music1.png"));
		Button.ButtonStyle style2 = new Button.ButtonStyle();
		style2.up = new TextureRegionDrawable(new TextureRegion(upMusicTexture));
		style2.down = new TextureRegionDrawable(new TextureRegion(donwMusicTexture));

		ButtonMusic = new Button(style2);
		ButtonMusic.setPosition(400,200);
		ButtonMusic.addListener(new ClickListener(){
				@Override
				public void clicked(InputEvent event,float x,float y){
					game.music.play();
				}
			});
		stage.addActor(ButtonMusic);
		
		upMusicTexture1 = new Texture(Gdx.files.internal("Music2.png"));
		donwMusicTexture1 = new  Texture(Gdx.files.internal("Music2.png"));
		Button.ButtonStyle style3 = new Button.ButtonStyle();
		style3.up = new TextureRegionDrawable(new TextureRegion(upMusicTexture1));
		style3.down = new TextureRegionDrawable(new TextureRegion(donwMusicTexture1));

		ButtonMusic1 = new Button(style3);
		ButtonMusic1.setPosition(700,200);
		ButtonMusic1.addListener(new ClickListener(){
				@Override
				public void clicked(InputEvent event,float x,float y){
					game.music.pause();
				}
			});
		stage.addActor(ButtonMusic1);
		
		upTexture1 = new Texture(Gdx.files.internal("button3.png"));
		downTexture1 = new  Texture(Gdx.files.internal("button4.png"));
		Button.ButtonStyle style1 = new Button.ButtonStyle();
		style1.up = new TextureRegionDrawable(new TextureRegion(upTexture1));
		style1.down = new TextureRegionDrawable(new TextureRegion(downTexture1));

		start1 = new Button(style1);
		start1.setPosition(1000,200);
		start1.addListener(new ClickListener(){
				@Override
				public void clicked(InputEvent event,float x,float y){
					Gdx.app.exit();
				}
			});
		stage.addActor(start1);
	}
	
	public void ButtonStart(){
		game.setScreen(new GameMain(game));
	}
	
	@Override
	public void render(float p1)
	{
		Gdx.gl.glClearColor(1, 1, 1, 1);
	    Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		stage.act();
        stage.draw();
	}

	@Override
	public void resize(int p1, int p2)
	{
		// TODO: Implement this method
	}

	@Override
	public void show()
	{
		// TODO: Implement this method
	}

	@Override
	public void hide()
	{
		// TODO: Implement this method
	}

	@Override
	public void pause()
	{
		// TODO: Implement this method
	}

	@Override
	public void resume()
	{
		// TODO: Implement this method
	}

	@Override
	public void dispose()
	{
        if (upTexture != null) {
            upTexture.dispose();
        }
		if (upTexture1 != null) {
            upTexture.dispose();
        }
		if(downTexture != null){
			downTexture.dispose();
		}
        if (downTexture1 != null) {
            downTexture1.dispose();
        }
        if (stage != null) {
            stage.dispose();
		}
	}
	
}
