package com.The.First;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.ui.Window.WindowStyle;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.*;
import com.badlogic.gdx.Application;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.*;
import com.badlogic.gdx.audio.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.math.*;
import java.util.*;
import android.view.*;

public class GameMain extends InputAdapter implements Screen
{
	private MyGdxGame game;
	OrthographicCamera camera;
	Stage stage;
	//暂停
	private Texture upTexture;
	private Texture downTexture;
	private Button button;
	//背景
	TextureRegion backgroundTexture;
	//演员Animation
	Animation ealkAnimation;
	List<Rectangle> rockPositions;
	Rectangle r;
	//主角
	Animation walkAnimation;
	Rectangle manPosition;
	Vector2 manVelocity;
	//游戏暂停对话框
	Window window,window1;
	Texture upTexture2;
	Texture downTexture2;
	Texture upTexture3;
	Texture downTexture3;
	Texture upTexture4;
	Texture downTexture4;
	Button button1;
	Button button2;
	Button button3;
	//游戏结束
	
	float time;
	float xo;
	float xi;
	float xq;
	float xe;
	
	public GameMain(MyGdxGame game){
		this.game = game;
		stage = new Stage();
		InputMultiplexer multiplexer = new InputMultiplexer();
        multiplexer.addProcessor(stage);
		multiplexer.addProcessor(this);
        Gdx.input.setInputProcessor(multiplexer);
		Gdx.input.setCatchBackKey(true);
		camera = new OrthographicCamera();
		configureCamera();
		//背景
		Texture texture = new Texture(Gdx.files.internal("BackgroundGame.jpg"));
		backgroundTexture = new TextureRegion(texture, 0, 0, 3045, 1080);
		//演员
		GameActor();
		//主角
		GameProtagonist();
		//主角大小和游戏大小
		resetGame();
		//游戏暂停对话框
		GameStop();
		//游戏结束对话框
		GameStop1();
	}
	////演员
	public void GameActor(){
		Texture texture2 = new Texture(Gdx.files.internal("Actor3.png"));
		int ACTOR_COLS = 7;
		int ACTOR_ROWS = 2;
		TextureRegion[][] tap = TextureRegion.split(texture2,texture2.getWidth() / ACTOR_COLS,texture2.getHeight() / ACTOR_ROWS);
		TextureRegion[] ealkFrames = new TextureRegion[ACTOR_COLS * ACTOR_ROWS];
		int indey = 0;
		for(int i = 0;i < ACTOR_ROWS;i++){
			for(int j = 0;j < ACTOR_COLS;j++){
				ealkFrames[indey++] = tap[i][j];
			}
		}
		ealkAnimation = new Animation(0.06f,ealkFrames);

		rockPositions = new ArrayList<Rectangle>();
		int x = 6000;
		for (int i = 0; i < 1000; i++)
		{
			rockPositions.add(new Rectangle(x, -60, 100, 100));
			x += 3000 + new Random().nextInt(3000);
		}
	}
	////主角
	public void GameProtagonist(){
		Texture walkSheet = new Texture(Gdx.files.internal("prot.png"));
		int FRAME_COLS = 4;
		int FRAME_ROWS = 2;
        TextureRegion[][] tmp = TextureRegion.split(walkSheet, walkSheet.getWidth() / FRAME_COLS, walkSheet.getHeight() / FRAME_ROWS);
        TextureRegion[] walkFrames = new TextureRegion[FRAME_COLS * FRAME_ROWS];
        int index = 0;
        for (int i = 0; i < FRAME_ROWS; i++)
		{
            for (int j = 0; j < FRAME_COLS; j++)
			{
                walkFrames[index++] = tmp[i][j];
            }
        }
        walkAnimation = new Animation(0.08f, walkFrames);
	}
	
	//暂停
	public void GameStop(){
        upTexture = new Texture(Gdx.files.internal("Stop3.png"));
        downTexture = new Texture(Gdx.files.internal("Stop4.png"));

        Button.ButtonStyle style = new Button.ButtonStyle();
        style.up = new TextureRegionDrawable(new TextureRegion(upTexture));
        style.down = new TextureRegionDrawable(new TextureRegion(downTexture));

        button = new Button(style);
		button.setPosition(15, 1015);
	    button.addListener(new InputListener(){
				@Override
				public boolean touchDown(InputEvent event, float x, float y,
										 int pointer, int button) {
					if(xo == 0){
						xo = xo +1;
						camera.translate(Gdx.graphics.getDeltaTime(),0);
					}else{
						xo = xo - 1;
					}

					if(xi == 0){
						xi = xi +1;
						time += Gdx.graphics.getDeltaTime();
					}else{
						xi = xi - 1;
					}
					
					xq = 0;
					stage.addActor(window);
					
					game.music.pause();
					return true;
				}
			});
		stage.addActor(button);
		
		upTexture2 = new Texture(Gdx.files.internal("Pops1.png"));
        downTexture2 = new Texture(Gdx.files.internal("Pop2.png"));

		upTexture3 = new Texture(Gdx.files.internal("Pop3.png"));
        downTexture3 = new Texture(Gdx.files.internal("Pop4.png"));

		upTexture4 = new Texture(Gdx.files.internal("Pop5.png"));
        downTexture4 = new Texture(Gdx.files.internal("Pop6.png"));

		//创建window(在这里也就是游戏对话框...)
	    BitmapFont font = new BitmapFont();
	    Texture backTexture = new Texture(Gdx.files.internal("Pop1.png"));
	    TextureRegionDrawable backDrawable = new TextureRegionDrawable(new TextureRegion(backTexture));
	    WindowStyle style1 = new WindowStyle(font, font.getColor(), backDrawable);
	    window = new Window(" ", style1);

	    window.setWidth(800);
	    window.setHeight(600);
	    window.setPosition(550, 200);
	    window.setModal(true);

		Button.ButtonStyle style2 = new Button.ButtonStyle();
        style2.up = new TextureRegionDrawable(new TextureRegion(upTexture2));
        style2.down = new TextureRegionDrawable(new TextureRegion(downTexture2));

		button1 = new Button(style2);
	    button1.addListener(new InputListener(){
				@Override
				public boolean touchDown(InputEvent event, float x, float y,
										 int pointer, int button) {
					resetGame(); 
					window.remove(); 
					xi = 0;
					xo = 0;
					xq = 0;
					return true;
				}
			});

	    Button.ButtonStyle style3 = new Button.ButtonStyle();
        style3.up = new TextureRegionDrawable(new TextureRegion(upTexture3));
        style3.down = new TextureRegionDrawable(new TextureRegion(downTexture3));

		button2 = new Button(style3);
	    button2.addListener(new InputListener(){
				@Override
				public boolean touchDown(InputEvent event, float x, float y,
										 int pointer, int button) {
					window.remove(); 
					xi = 0;
					xo = 0;
					xq = 0;
					game.music.play();
					return true;
				}
			});

        Button.ButtonStyle style4 = new Button.ButtonStyle();
        style4.up = new TextureRegionDrawable(new TextureRegion(upTexture4));
        style4.down = new TextureRegionDrawable(new TextureRegion(downTexture4));

		button3 = new Button(style4);
	    button3.addListener(new InputListener(){
				@Override
				public boolean touchDown(InputEvent event, float x, float y,
										 int pointer, int button) {
					xq = 0;		
					window.remove(); 
					game.setScreen(new GameStart(game));
					return true;
				}
			});

        //给按钮设置位置
		button1.setPosition(300,205);
        button2.setPosition(300, 365);
        button3.setPosition(300, 40);

        //给window添加演员
        window.addActor(button1);
        window.addActor(button2);
		window.addActor(button3);
	}
	
	public void GameStop1(){
		upTexture3 = new Texture(Gdx.files.internal("Pops1.png"));
        downTexture3 = new Texture(Gdx.files.internal("Pop2.png"));

		upTexture4 = new Texture(Gdx.files.internal("Pop5.png"));
        downTexture4 = new Texture(Gdx.files.internal("Pop6.png"));

		//创建window(在这里也就是游戏对话框...)
	    BitmapFont font = new BitmapFont();
	    Texture backTexture = new Texture(Gdx.files.internal("hello.png"));
	    TextureRegionDrawable backDrawable = new TextureRegionDrawable(new TextureRegion(backTexture));
	    WindowStyle style1 = new WindowStyle(font, font.getColor(), backDrawable);
	    window1 = new Window(" ", style1);

	    window1.setWidth(800);
	    window1.setHeight(400);
	    window1.setPosition(550, 300);
	    window1.setModal(true);

	    Button.ButtonStyle style3 = new Button.ButtonStyle();
        style3.up = new TextureRegionDrawable(new TextureRegion(upTexture3));
        style3.down = new TextureRegionDrawable(new TextureRegion(downTexture3));

		button2 = new Button(style3);
	    button2.addListener(new InputListener(){
				@Override
				public boolean touchDown(InputEvent event, float x, float y,
										 int pointer, int button) {
					resetGame();
					window1.remove(); 
					xi = 0;
					xo = 0;
					xq = 0;
					game.music.play();
					return true;
				}
			});

        Button.ButtonStyle style4 = new Button.ButtonStyle();
        style4.up = new TextureRegionDrawable(new TextureRegion(upTexture4));
        style4.down = new TextureRegionDrawable(new TextureRegion(downTexture4));

		button3 = new Button(style4);
	    button3.addListener(new InputListener(){
				@Override
				public boolean touchDown(InputEvent event, float x, float y,
										 int pointer, int button) {
					xq = 0;
					window1.remove(); 
					game.setScreen(new GameStart(game));
					game.music.play();
					return true;
				}
			});

        //给按钮设置位置
        button2.setPosition(300, 160);
        button3.setPosition(300, 40);

        //给window添加演员
        window1.addActor(button2);
		window1.addActor(button3);
	}
	
	public void io(){
		
	}
	@Override
	public void render(float p1)
	{
		Gdx.gl.glClearColor(0,0,0,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
		
		camera.update();
		game.batch.setProjectionMatrix(camera.combined);
		game.batch.begin();
		//绘制背景
		for (int i = 0; i < 100; i++)
		game.batch.draw(backgroundTexture,i * 3045, 0, 3045, 1080);
		//绘制演员
		for (Rectangle r : rockPositions)
			game.batch.draw(ealkAnimation.getKeyFrame(time,true), r.x, r.y, 900, 400);
		//绘制主角
		game.batch.draw(walkAnimation.getKeyFrame(time, true), manPosition.x, manPosition.y, manPosition.width, manPosition.height);
		game.font.draw(game.batch, (int) (manPosition.x / 70) + "m", camera.position.x + 1400, 1040);
        game.batch.end();
		//绘制舞台
		stage.act();
        stage.draw();
		//移动背景
		if(xo == 0)
			camera.translate(1500 * Gdx.graphics.getDeltaTime(), 0);
		//检测主角和演员碰撞
		for (Rectangle r : rockPositions)
		{
			if (r.overlaps(manPosition) && r.getCenter(new Vector2()).dst(manPosition.getCenter(new Vector2())) < 220)
			{
				//resetGame();
				stage.addActor(window1);
				xi = 1;
				xo = 1;
				if(xq == 0){
					xq = xq + 1;
				}
				break;
			}
		}
		//移动主角
		if(xi == 0)
		time += Gdx.graphics.getDeltaTime();
		if(xi == 0)
		manPosition.x += manVelocity.x * Gdx.graphics.getDeltaTime();
		manPosition.y += manVelocity.y * Gdx.graphics.getDeltaTime();
		manVelocity.y -= 1000 * Gdx.graphics.getDeltaTime();
		if (Gdx.input.isTouched() && manPosition.y == 0)
		{
			if(xq == 0)
			manVelocity.y = 800;
		}
		if (manPosition.y < 0) 
		{
			manPosition.y = 0;
			manVelocity.y = 0;
		}
	}

	private void configureCamera()
	{
		if (Gdx.graphics.getHeight() < Gdx.graphics.getWidth())
			camera.setToOrtho(false,3045,1080);
		else
			camera.setToOrtho(false,3045,1080);
	}
	
	private void resetGame()
	{
		configureCamera();
		manPosition = new Rectangle(0, 0, 900, 400);
		manVelocity = new Vector2(1500, 0);
	}
	
	@Override
	public void resize(int p1, int p2)
	{
		// TODO: Implement this method
	}

	@Override
	public void show()
	{
		// TODO: Implement this method
	}

	@Override
	public void hide()
	{
		// TODO: Implement this method
	}

	@Override
	public void pause()
	{
		// TODO: Implement this method
	}

	@Override
	public void resume()
	{
		// TODO: Implement this method
	}

	@Override
	public void dispose()
	{
		// 应用退出时释放资源
        if (upTexture != null) {
            upTexture.dispose();
        }
		if (upTexture2 != null) {
            upTexture2.dispose();

        }
		if (upTexture3 != null) {
            upTexture3.dispose();

        }
		if (upTexture4 != null) {
            upTexture4.dispose();

        }
        if (downTexture != null) {
            downTexture.dispose();
        }
		if (downTexture2 != null) {
            downTexture2.dispose();
        }
		if (downTexture3 != null) {
            downTexture3.dispose();
        }
		if (downTexture4 != null) {
            downTexture4.dispose();
        }
        if (stage != null) {
            stage.dispose();
        }
	}

	@Override
	public boolean keyDown(int keycode)
	{
		stage.addActor(window);
		xi = 1;
		xo = 1;
		xq = 1;
		game.music.pause();
		return false;
	}
	
}
